import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import geofences from './geofences'
import departments from './departments'
import users from './users'
import roles from './roles'
import attendanceC12b95 from './attendance'
import reports3613d0 from './reports'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminDashboardController::dashboard
 * @see app/Http/Controllers/SuperAdmin/AdminDashboardController.php:17
 * @route '/admin/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
export const geofencing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: geofencing.url(options),
    method: 'get',
})

geofencing.definition = {
    methods: ["get","head"],
    url: '/admin/geofences',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
geofencing.url = (options?: RouteQueryOptions) => {
    return geofencing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
geofencing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: geofencing.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
geofencing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: geofencing.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
    const geofencingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: geofencing.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
        geofencingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: geofencing.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminGeoFencingController::geofencing
 * @see app/Http/Controllers/SuperAdmin/AdminGeoFencingController.php:23
 * @route '/admin/geofences'
 */
        geofencingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: geofencing.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    geofencing.form = geofencingForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
export const masterdata = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: masterdata.url(options),
    method: 'get',
})

masterdata.definition = {
    methods: ["get","head"],
    url: '/admin/masterdata',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
masterdata.url = (options?: RouteQueryOptions) => {
    return masterdata.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
masterdata.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: masterdata.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
masterdata.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: masterdata.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
    const masterdataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: masterdata.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
        masterdataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: masterdata.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::masterdata
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
        masterdataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: masterdata.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    masterdata.form = masterdataForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
export const user_management = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user_management.url(options),
    method: 'get',
})

user_management.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
user_management.url = (options?: RouteQueryOptions) => {
    return user_management.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
user_management.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user_management.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
user_management.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: user_management.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
    const user_managementForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: user_management.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
        user_managementForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user_management.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::user_management
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
        user_managementForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user_management.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    user_management.form = user_managementForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
export const attendance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(options),
    method: 'get',
})

attendance.definition = {
    methods: ["get","head"],
    url: '/admin/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
attendance.url = (options?: RouteQueryOptions) => {
    return attendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
attendance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
attendance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attendance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
    const attendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attendance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
        attendanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::attendance
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
        attendanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attendance.form = attendanceForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
    const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
        reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminReportsController::reports
 * @see app/Http/Controllers/SuperAdmin/AdminReportsController.php:14
 * @route '/admin/reports'
 */
        reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reports.form = reportsForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
geofencing: Object.assign(geofencing, geofencing),
geofences: Object.assign(geofences, geofences),
masterdata: Object.assign(masterdata, masterdata),
departments: Object.assign(departments, departments),
users: Object.assign(users, users),
roles: Object.assign(roles, roles),
user_management: Object.assign(user_management, user_management),
attendance: Object.assign(attendance, attendanceC12b95),
reports: Object.assign(reports, reports3613d0),
}

export default admin