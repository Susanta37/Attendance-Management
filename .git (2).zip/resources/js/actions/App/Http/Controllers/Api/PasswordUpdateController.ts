import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PasswordUpdateController::update
 * @see app/Http/Controllers/Api/PasswordUpdateController.php:16
 * @route '/api/user/password'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/user/password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\PasswordUpdateController::update
 * @see app/Http/Controllers/Api/PasswordUpdateController.php:16
 * @route '/api/user/password'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PasswordUpdateController::update
 * @see app/Http/Controllers/Api/PasswordUpdateController.php:16
 * @route '/api/user/password'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\PasswordUpdateController::update
 * @see app/Http/Controllers/Api/PasswordUpdateController.php:16
 * @route '/api/user/password'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PasswordUpdateController::update
 * @see app/Http/Controllers/Api/PasswordUpdateController.php:16
 * @route '/api/user/password'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const PasswordUpdateController = { update }

export default PasswordUpdateController