import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/employee/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/employee/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
export const checkFirstLogin = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkFirstLogin.url(options),
    method: 'get',
})

checkFirstLogin.definition = {
    methods: ["get","head"],
    url: '/api/check-first-login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
checkFirstLogin.url = (options?: RouteQueryOptions) => {
    return checkFirstLogin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
checkFirstLogin.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkFirstLogin.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
checkFirstLogin.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkFirstLogin.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
    const checkFirstLoginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: checkFirstLogin.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
        checkFirstLoginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkFirstLogin.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::checkFirstLogin
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:53
 * @route '/api/check-first-login'
 */
        checkFirstLoginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkFirstLogin.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    checkFirstLogin.form = checkFirstLoginForm
const EmployeeAuthController = { login, logout, checkFirstLogin }

export default EmployeeAuthController