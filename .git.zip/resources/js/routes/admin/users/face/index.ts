import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
export const enroll = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enroll.url(args, options),
    method: 'post',
})

enroll.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/face/enroll',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
enroll.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return enroll.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
enroll.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enroll.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
    const enrollForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: enroll.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
        enrollForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: enroll.url(args, options),
            method: 'post',
        })
    
    enroll.form = enrollForm
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reenroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
export const reenroll = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reenroll.url(args, options),
    method: 'post',
})

reenroll.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/face/re-enroll',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reenroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
reenroll.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return reenroll.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reenroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
reenroll.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reenroll.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reenroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
    const reenrollForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reenroll.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reenroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
        reenrollForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reenroll.url(args, options),
            method: 'post',
        })
    
    reenroll.form = reenrollForm
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteMethod
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
export const deleteMethod = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

deleteMethod.definition = {
    methods: ["delete"],
    url: '/admin/users/{user}/face',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteMethod
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
deleteMethod.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return deleteMethod.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteMethod
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
deleteMethod.delete = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteMethod
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
    const deleteMethodForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMethod.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteMethod
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
        deleteMethodForm.delete = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteMethod.form = deleteMethodForm
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
export const status = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/admin/users/{user}/face/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
status.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return status.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
status.get = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
status.head = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
    const statusForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: status.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
        statusForm.get = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
        statusForm.head = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    status.form = statusForm
const face = {
    enroll: Object.assign(enroll, enroll),
reenroll: Object.assign(reenroll, reenroll),
delete: Object.assign(deleteMethod, deleteMethod),
status: Object.assign(status, status),
}

export default face