import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::index
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:18
 * @route '/admin/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
export const getUserAttendances = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserAttendances.url(args, options),
    method: 'get',
})

getUserAttendances.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{userId}/records',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
getUserAttendances.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return getUserAttendances.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
getUserAttendances.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserAttendances.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
getUserAttendances.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserAttendances.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
    const getUserAttendancesForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getUserAttendances.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
        getUserAttendancesForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUserAttendances.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getUserAttendances
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
        getUserAttendancesForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUserAttendances.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getUserAttendances.form = getUserAttendancesForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
export const getLiveLocation = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLiveLocation.url(args, options),
    method: 'get',
})

getLiveLocation.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{userId}/live-location',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
getLiveLocation.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return getLiveLocation.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
getLiveLocation.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLiveLocation.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
getLiveLocation.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getLiveLocation.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
    const getLiveLocationForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getLiveLocation.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
        getLiveLocationForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getLiveLocation.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::getLiveLocation
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
        getLiveLocationForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getLiveLocation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getLiveLocation.form = getLiveLocationForm
const AdminAttendanceController = { index, getUserAttendances, getLiveLocation }

export default AdminAttendanceController