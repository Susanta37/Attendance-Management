import AdminUserManagementController from './AdminUserManagementController'
import AdminDashboardController from './AdminDashboardController'
import AdminGeoFencingController from './AdminGeoFencingController'
import AdminMasterDataController from './AdminMasterDataController'
import AdminAttendanceController from './AdminAttendanceController'
import AdminReportsController from './AdminReportsController'
import AdminLiveTracking from './AdminLiveTracking'
import UserDocumentController from './UserDocumentController'
import FaceEnrollmentController from './FaceEnrollmentController'
const SuperAdmin = {
    AdminUserManagementController: Object.assign(AdminUserManagementController, AdminUserManagementController),
AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
AdminGeoFencingController: Object.assign(AdminGeoFencingController, AdminGeoFencingController),
AdminMasterDataController: Object.assign(AdminMasterDataController, AdminMasterDataController),
AdminAttendanceController: Object.assign(AdminAttendanceController, AdminAttendanceController),
AdminReportsController: Object.assign(AdminReportsController, AdminReportsController),
AdminLiveTracking: Object.assign(AdminLiveTracking, AdminLiveTracking),
UserDocumentController: Object.assign(UserDocumentController, UserDocumentController),
FaceEnrollmentController: Object.assign(FaceEnrollmentController, FaceEnrollmentController),
}

export default SuperAdmin