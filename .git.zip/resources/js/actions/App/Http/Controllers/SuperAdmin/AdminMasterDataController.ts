import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/masterdata',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::index
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:16
 * @route '/admin/masterdata'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeDepartment
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:67
 * @route '/admin/departments'
 */
export const storeDepartment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDepartment.url(options),
    method: 'post',
})

storeDepartment.definition = {
    methods: ["post"],
    url: '/admin/departments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeDepartment
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:67
 * @route '/admin/departments'
 */
storeDepartment.url = (options?: RouteQueryOptions) => {
    return storeDepartment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeDepartment
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:67
 * @route '/admin/departments'
 */
storeDepartment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDepartment.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeDepartment
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:67
 * @route '/admin/departments'
 */
    const storeDepartmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeDepartment.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeDepartment
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:67
 * @route '/admin/departments'
 */
        storeDepartmentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeDepartment.url(options),
            method: 'post',
        })
    
    storeDepartment.form = storeDepartmentForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeUser
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
export const storeUser = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeUser.url(options),
    method: 'post',
})

storeUser.definition = {
    methods: ["post"],
    url: '/admin/users-create',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeUser
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
storeUser.url = (options?: RouteQueryOptions) => {
    return storeUser.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeUser
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
storeUser.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeUser.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeUser
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
    const storeUserForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeUser.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeUser
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
        storeUserForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeUser.url(options),
            method: 'post',
        })
    
    storeUser.form = storeUserForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeRole
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:96
 * @route '/admin/roles'
 */
export const storeRole = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRole.url(options),
    method: 'post',
})

storeRole.definition = {
    methods: ["post"],
    url: '/admin/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeRole
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:96
 * @route '/admin/roles'
 */
storeRole.url = (options?: RouteQueryOptions) => {
    return storeRole.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeRole
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:96
 * @route '/admin/roles'
 */
storeRole.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRole.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeRole
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:96
 * @route '/admin/roles'
 */
    const storeRoleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeRole.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::storeRole
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:96
 * @route '/admin/roles'
 */
        storeRoleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeRole.url(options),
            method: 'post',
        })
    
    storeRole.form = storeRoleForm
const AdminMasterDataController = { index, storeDepartment, storeUser, storeRole }

export default AdminMasterDataController