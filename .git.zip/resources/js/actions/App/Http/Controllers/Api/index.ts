import EmployeeAuthController from './EmployeeAuthController'
import ForgotPasswordController from './ForgotPasswordController'
import ResetPasswordController from './ResetPasswordController'
import PasswordUpdateController from './PasswordUpdateController'
import FaceApiController from './FaceApiController'
import AttendanceController from './AttendanceController'
import DashboardController from './DashboardController'
import AttendanceHistoryController from './AttendanceHistoryController'
import ProfileController from './ProfileController'
const Api = {
    EmployeeAuthController: Object.assign(EmployeeAuthController, EmployeeAuthController),
ForgotPasswordController: Object.assign(ForgotPasswordController, ForgotPasswordController),
ResetPasswordController: Object.assign(ResetPasswordController, ResetPasswordController),
PasswordUpdateController: Object.assign(PasswordUpdateController, PasswordUpdateController),
FaceApiController: Object.assign(FaceApiController, FaceApiController),
AttendanceController: Object.assign(AttendanceController, AttendanceController),
DashboardController: Object.assign(DashboardController, DashboardController),
AttendanceHistoryController: Object.assign(AttendanceHistoryController, AttendanceHistoryController),
ProfileController: Object.assign(ProfileController, ProfileController),
}

export default Api