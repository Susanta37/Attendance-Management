import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
export const getBlocks = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBlocks.url(args, options),
    method: 'get',
})

getBlocks.definition = {
    methods: ["get","head"],
    url: '/api/blocks/{districtId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
getBlocks.url = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { districtId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    districtId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        districtId: args.districtId,
                }

    return getBlocks.definition.url
            .replace('{districtId}', parsedArgs.districtId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
getBlocks.get = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBlocks.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
getBlocks.head = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getBlocks.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
    const getBlocksForm = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getBlocks.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
        getBlocksForm.get = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getBlocks.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getBlocks
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:137
 * @route '/api/blocks/{districtId}'
 */
        getBlocksForm.head = (args: { districtId: string | number } | [districtId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getBlocks.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getBlocks.form = getBlocksForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
export const getGps = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getGps.url(args, options),
    method: 'get',
})

getGps.definition = {
    methods: ["get","head"],
    url: '/api/gps/{blockId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
getGps.url = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { blockId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    blockId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        blockId: args.blockId,
                }

    return getGps.definition.url
            .replace('{blockId}', parsedArgs.blockId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
getGps.get = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getGps.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
getGps.head = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getGps.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
    const getGpsForm = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getGps.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
        getGpsForm.get = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getGps.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::getGps
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:145
 * @route '/api/gps/{blockId}'
 */
        getGpsForm.head = (args: { blockId: string | number } | [blockId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getGps.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getGps.form = getGpsForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::index
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:24
 * @route '/admin/users'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::store
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:157
 * @route '/admin/users'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::store
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:157
 * @route '/admin/users'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::store
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:157
 * @route '/admin/users'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::store
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:157
 * @route '/admin/users'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::store
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:157
 * @route '/admin/users'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::update
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:220
 * @route '/admin/users/{user}'
 */
export const update = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/users/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::update
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:220
 * @route '/admin/users/{user}'
 */
update.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return update.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::update
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:220
 * @route '/admin/users/{user}'
 */
update.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::update
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:220
 * @route '/admin/users/{user}'
 */
    const updateForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::update
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:220
 * @route '/admin/users/{user}'
 */
        updateForm.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::destroy
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:276
 * @route '/admin/users/{user}'
 */
export const destroy = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/users/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::destroy
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:276
 * @route '/admin/users/{user}'
 */
destroy.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::destroy
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:276
 * @route '/admin/users/{user}'
 */
destroy.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::destroy
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:276
 * @route '/admin/users/{user}'
 */
    const destroyForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::destroy
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:276
 * @route '/admin/users/{user}'
 */
        destroyForm.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::restore
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:288
 * @route '/admin/users/{user}/restore'
 */
export const restore = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::restore
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:288
 * @route '/admin/users/{user}/restore'
 */
restore.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return restore.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::restore
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:288
 * @route '/admin/users/{user}/restore'
 */
restore.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::restore
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:288
 * @route '/admin/users/{user}/restore'
 */
    const restoreForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminUserManagementController::restore
 * @see app/Http/Controllers/SuperAdmin/AdminUserManagementController.php:288
 * @route '/admin/users/{user}/restore'
 */
        restoreForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
const AdminUserManagementController = { getBlocks, getGps, index, store, update, destroy, restore }

export default AdminUserManagementController