import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/manager/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Manager\ManagerDashboardController::index
 * @see app/Http/Controllers/Manager/ManagerDashboardController.php:10
 * @route '/manager/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const ManagerDashboardController = { index }

export default ManagerDashboardController