import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
export const user_records = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user_records.url(args, options),
    method: 'get',
})

user_records.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{userId}/records',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
user_records.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return user_records.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
user_records.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user_records.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
user_records.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: user_records.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
    const user_recordsForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: user_records.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
        user_recordsForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user_records.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::user_records
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:149
 * @route '/admin/attendance/{userId}/records'
 */
        user_recordsForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user_records.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    user_records.form = user_recordsForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
export const live_location = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: live_location.url(args, options),
    method: 'get',
})

live_location.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{userId}/live-location',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
live_location.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return live_location.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
live_location.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: live_location.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
live_location.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: live_location.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
    const live_locationForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: live_location.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
        live_locationForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: live_location.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminAttendanceController::live_location
 * @see app/Http/Controllers/SuperAdmin/AdminAttendanceController.php:166
 * @route '/admin/attendance/{userId}/live-location'
 */
        live_locationForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: live_location.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    live_location.form = live_locationForm
const attendance = {
    user_records: Object.assign(user_records, user_records),
live_location: Object.assign(live_location, live_location),
}

export default attendance