import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/employee/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::login
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:12
 * @route '/api/employee/login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/employee/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\EmployeeAuthController::logout
 * @see app/Http/Controllers/Api/EmployeeAuthController.php:45
 * @route '/api/employee/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\Api\AttendanceController::checkin
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
export const checkin = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkin.url(options),
    method: 'post',
})

checkin.definition = {
    methods: ["post"],
    url: '/api/employee/check-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkin
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
checkin.url = (options?: RouteQueryOptions) => {
    return checkin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkin
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
checkin.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkin.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::checkin
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
    const checkinForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkin.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::checkin
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
        checkinForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkin.url(options),
            method: 'post',
        })
    
    checkin.form = checkinForm
/**
* @see \App\Http\Controllers\Api\AttendanceController::checkout
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/api/employee/check-out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkout
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkout
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
checkout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::checkout
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
    const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::checkout
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
        checkoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkout.url(options),
            method: 'post',
        })
    
    checkout.form = checkoutForm
/**
* @see \App\Http\Controllers\Api\AttendanceController::livelocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
export const livelocation = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: livelocation.url(options),
    method: 'post',
})

livelocation.definition = {
    methods: ["post"],
    url: '/api/employee/live-location',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::livelocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
livelocation.url = (options?: RouteQueryOptions) => {
    return livelocation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::livelocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
livelocation.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: livelocation.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::livelocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
    const livelocationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: livelocation.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::livelocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
        livelocationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: livelocation.url(options),
            method: 'post',
        })
    
    livelocation.form = livelocationForm
const employee = {
    login: Object.assign(login, login),
logout: Object.assign(logout, logout),
checkin: Object.assign(checkin, checkin),
checkout: Object.assign(checkout, checkout),
livelocation: Object.assign(livelocation, livelocation),
}

export default employee