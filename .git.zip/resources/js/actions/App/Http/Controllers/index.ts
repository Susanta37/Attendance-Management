import Api from './Api'
import SuperAdmin from './SuperAdmin'
import Manager from './Manager'
import Settings from './Settings'
const Controllers = {
    Api: Object.assign(Api, Api),
SuperAdmin: Object.assign(SuperAdmin, SuperAdmin),
Manager: Object.assign(Manager, Manager),
Settings: Object.assign(Settings, Settings),
}

export default Controllers