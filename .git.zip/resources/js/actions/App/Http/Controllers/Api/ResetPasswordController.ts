import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ResetPasswordController::reset
 * @see app/Http/Controllers/Api/ResetPasswordController.php:12
 * @route '/api/reset-password'
 */
export const reset = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

reset.definition = {
    methods: ["post"],
    url: '/api/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ResetPasswordController::reset
 * @see app/Http/Controllers/Api/ResetPasswordController.php:12
 * @route '/api/reset-password'
 */
reset.url = (options?: RouteQueryOptions) => {
    return reset.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ResetPasswordController::reset
 * @see app/Http/Controllers/Api/ResetPasswordController.php:12
 * @route '/api/reset-password'
 */
reset.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ResetPasswordController::reset
 * @see app/Http/Controllers/Api/ResetPasswordController.php:12
 * @route '/api/reset-password'
 */
    const resetForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reset.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ResetPasswordController::reset
 * @see app/Http/Controllers/Api/ResetPasswordController.php:12
 * @route '/api/reset-password'
 */
        resetForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reset.url(options),
            method: 'post',
        })
    
    reset.form = resetForm
const ResetPasswordController = { reset }

export default ResetPasswordController