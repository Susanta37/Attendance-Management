import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/lt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const AdminLiveTracking = { index }

export default AdminLiveTracking