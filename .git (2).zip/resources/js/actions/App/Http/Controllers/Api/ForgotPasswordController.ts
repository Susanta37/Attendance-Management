import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ForgotPasswordController::sendResetLink
 * @see app/Http/Controllers/Api/ForgotPasswordController.php:15
 * @route '/api/forgot-password'
 */
export const sendResetLink = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendResetLink.url(options),
    method: 'post',
})

sendResetLink.definition = {
    methods: ["post"],
    url: '/api/forgot-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ForgotPasswordController::sendResetLink
 * @see app/Http/Controllers/Api/ForgotPasswordController.php:15
 * @route '/api/forgot-password'
 */
sendResetLink.url = (options?: RouteQueryOptions) => {
    return sendResetLink.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForgotPasswordController::sendResetLink
 * @see app/Http/Controllers/Api/ForgotPasswordController.php:15
 * @route '/api/forgot-password'
 */
sendResetLink.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendResetLink.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ForgotPasswordController::sendResetLink
 * @see app/Http/Controllers/Api/ForgotPasswordController.php:15
 * @route '/api/forgot-password'
 */
    const sendResetLinkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendResetLink.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForgotPasswordController::sendResetLink
 * @see app/Http/Controllers/Api/ForgotPasswordController.php:15
 * @route '/api/forgot-password'
 */
        sendResetLinkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendResetLink.url(options),
            method: 'post',
        })
    
    sendResetLink.form = sendResetLinkForm
const ForgotPasswordController = { sendResetLink }

export default ForgotPasswordController