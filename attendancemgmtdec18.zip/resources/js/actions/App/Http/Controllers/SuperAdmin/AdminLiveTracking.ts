import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/lt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::index
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:16
 * @route '/admin/lt'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::markNotificationRead
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:153
 * @route '/admin/notifications/{alert}/read'
 */
export const markNotificationRead = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markNotificationRead.url(args, options),
    method: 'post',
})

markNotificationRead.definition = {
    methods: ["post"],
    url: '/admin/notifications/{alert}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::markNotificationRead
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:153
 * @route '/admin/notifications/{alert}/read'
 */
markNotificationRead.url = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { alert: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { alert: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    alert: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        alert: typeof args.alert === 'object'
                ? args.alert.id
                : args.alert,
                }

    return markNotificationRead.definition.url
            .replace('{alert}', parsedArgs.alert.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::markNotificationRead
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:153
 * @route '/admin/notifications/{alert}/read'
 */
markNotificationRead.post = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markNotificationRead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::markNotificationRead
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:153
 * @route '/admin/notifications/{alert}/read'
 */
    const markNotificationReadForm = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markNotificationRead.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminLiveTracking::markNotificationRead
 * @see app/Http/Controllers/SuperAdmin/AdminLiveTracking.php:153
 * @route '/admin/notifications/{alert}/read'
 */
        markNotificationReadForm.post = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markNotificationRead.url(args, options),
            method: 'post',
        })
    
    markNotificationRead.form = markNotificationReadForm
const AdminLiveTracking = { index, markNotificationRead }

export default AdminLiveTracking