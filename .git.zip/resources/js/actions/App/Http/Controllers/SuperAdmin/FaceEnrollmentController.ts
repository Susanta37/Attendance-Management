import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
export const enroll = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enroll.url(args, options),
    method: 'post',
})

enroll.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/face/enroll',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
enroll.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return enroll.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
enroll.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enroll.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
    const enrollForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: enroll.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::enroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:18
 * @route '/admin/users/{user}/face/enroll'
 */
        enrollForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: enroll.url(args, options),
            method: 'post',
        })
    
    enroll.form = enrollForm
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reEnroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
export const reEnroll = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reEnroll.url(args, options),
    method: 'post',
})

reEnroll.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/face/re-enroll',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reEnroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
reEnroll.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return reEnroll.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reEnroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
reEnroll.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reEnroll.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reEnroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
    const reEnrollForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reEnroll.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::reEnroll
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:40
 * @route '/admin/users/{user}/face/re-enroll'
 */
        reEnrollForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reEnroll.url(args, options),
            method: 'post',
        })
    
    reEnroll.form = reEnrollForm
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteFace
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
export const deleteFace = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteFace.url(args, options),
    method: 'delete',
})

deleteFace.definition = {
    methods: ["delete"],
    url: '/admin/users/{user}/face',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteFace
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
deleteFace.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return deleteFace.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteFace
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
deleteFace.delete = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteFace.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteFace
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
    const deleteFaceForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteFace.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::deleteFace
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:54
 * @route '/admin/users/{user}/face'
 */
        deleteFaceForm.delete = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteFace.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteFace.form = deleteFaceForm
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
export const status = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/admin/users/{user}/face/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
status.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return status.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
status.get = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
status.head = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
    const statusForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: status.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
        statusForm.get = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdmin\FaceEnrollmentController::status
 * @see app/Http/Controllers/SuperAdmin/FaceEnrollmentController.php:82
 * @route '/admin/users/{user}/face/status'
 */
        statusForm.head = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    status.form = statusForm
const FaceEnrollmentController = { enroll, reEnroll, deleteFace, status }

export default FaceEnrollmentController