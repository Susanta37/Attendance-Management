import password from './password'
import userPassword from './user-password'
const api = {
    password: Object.assign(password, password),
userPassword: Object.assign(userPassword, userPassword),
}

export default api