import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\FaceApiController::enrollFace
 * @see app/Http/Controllers/Api/FaceApiController.php:14
 * @route '/api/face/enroll'
 */
export const enrollFace = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enrollFace.url(options),
    method: 'post',
})

enrollFace.definition = {
    methods: ["post"],
    url: '/api/face/enroll',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FaceApiController::enrollFace
 * @see app/Http/Controllers/Api/FaceApiController.php:14
 * @route '/api/face/enroll'
 */
enrollFace.url = (options?: RouteQueryOptions) => {
    return enrollFace.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FaceApiController::enrollFace
 * @see app/Http/Controllers/Api/FaceApiController.php:14
 * @route '/api/face/enroll'
 */
enrollFace.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enrollFace.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\FaceApiController::enrollFace
 * @see app/Http/Controllers/Api/FaceApiController.php:14
 * @route '/api/face/enroll'
 */
    const enrollFaceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: enrollFace.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\FaceApiController::enrollFace
 * @see app/Http/Controllers/Api/FaceApiController.php:14
 * @route '/api/face/enroll'
 */
        enrollFaceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: enrollFace.url(options),
            method: 'post',
        })
    
    enrollFace.form = enrollFaceForm
const FaceApiController = { enrollFace }

export default FaceApiController