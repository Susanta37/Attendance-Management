import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
export const status = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/api/attendance/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
status.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
status.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
    const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: status.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
        statusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\AttendanceController::status
 * @see app/Http/Controllers/Api/AttendanceController.php:383
 * @route '/api/attendance/status'
 */
        statusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
export const checkIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(options),
    method: 'post',
})

checkIn.definition = {
    methods: ["post"],
    url: '/api/employee/check-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
checkIn.url = (options?: RouteQueryOptions) => {
    return checkIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
checkIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
    const checkInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::checkIn
 * @see app/Http/Controllers/Api/AttendanceController.php:25
 * @route '/api/employee/check-in'
 */
        checkInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkIn.url(options),
            method: 'post',
        })
    
    checkIn.form = checkInForm
/**
* @see \App\Http\Controllers\Api\AttendanceController::checkOut
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
export const checkOut = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkOut.url(options),
    method: 'post',
})

checkOut.definition = {
    methods: ["post"],
    url: '/api/employee/check-out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkOut
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
checkOut.url = (options?: RouteQueryOptions) => {
    return checkOut.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::checkOut
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
checkOut.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkOut.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::checkOut
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
    const checkOutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkOut.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::checkOut
 * @see app/Http/Controllers/Api/AttendanceController.php:227
 * @route '/api/employee/check-out'
 */
        checkOutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkOut.url(options),
            method: 'post',
        })
    
    checkOut.form = checkOutForm
/**
* @see \App\Http\Controllers\Api\AttendanceController::liveLocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
export const liveLocation = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: liveLocation.url(options),
    method: 'post',
})

liveLocation.definition = {
    methods: ["post"],
    url: '/api/employee/live-location',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AttendanceController::liveLocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
liveLocation.url = (options?: RouteQueryOptions) => {
    return liveLocation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AttendanceController::liveLocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
liveLocation.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: liveLocation.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AttendanceController::liveLocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
    const liveLocationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: liveLocation.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AttendanceController::liveLocation
 * @see app/Http/Controllers/Api/AttendanceController.php:321
 * @route '/api/employee/live-location'
 */
        liveLocationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: liveLocation.url(options),
            method: 'post',
        })
    
    liveLocation.form = liveLocationForm
const AttendanceController = { status, checkIn, checkOut, liveLocation }

export default AttendanceController