import ManagerDashboardController from './ManagerDashboardController'
const Manager = {
    ManagerDashboardController: Object.assign(ManagerDashboardController, ManagerDashboardController),
}

export default Manager