import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::master
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
export const master = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: master.url(options),
    method: 'post',
})

master.definition = {
    methods: ["post"],
    url: '/admin/users-create',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::master
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
master.url = (options?: RouteQueryOptions) => {
    return master.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::master
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
master.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: master.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::master
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
    const masterForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: master.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SuperAdmin\AdminMasterDataController::master
 * @see app/Http/Controllers/SuperAdmin/AdminMasterDataController.php:79
 * @route '/admin/users-create'
 */
        masterForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: master.url(options),
            method: 'post',
        })
    
    master.form = masterForm